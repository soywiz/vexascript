# Oilpan / cppgc Hello World

Minimal C++ project that uses Oilpan, exposed in V8 as `cppgc`, without linking
against the full V8 runtime.

The `gc/` directory contains a vendored, trimmed copy of cppgc/Oilpan and the
required support pieces (`src/base`, `src/heap/base`, `v8-platform.h`,
`v8config.h`). There are no submodules, `fetch`, `gclient`, GN, or `v8_monolith`
in the normal build path.

## Requirements

- CMake 3.20+
- C++20 compiler
- Make

This trimmed build is prepared for macOS and Linux on `arm64/aarch64` or
`x86_64`.

## Build

From this directory:

```sh
make
./build/oilpan_hello
```

The same build can be driven directly through CMake:

```sh
cmake -S . -B build
cmake --build build
./build/oilpan_hello
```

Expected output, with memory values and timings varying by platform:

```text
benchmark config short_lived_count=1000000 quick_gc_rounds=5 retained_count=50000 initial_heap=...
automatic atomic GC starts around ... of live+new cppgc object bytes in this sample
GC modes: fast/precise=kNoHeapPointers, slow/conservative=kMayContainHeapPointers
start                            cppgc_objects=0 B cppgc_space=0 B rss=...
Hello, Oilpan long-lived root checksum=...
after long-lived                 cppgc_objects=...
quick fast GC #1                 mode=fast/precise ...
quick fast summary               count=5 min=... avg=... max=...
quick slow summary               count=5 min=... avg=... max=...
fast churn allocation            elapsed=... auto_gc_count=... auto_gc_time=...
after fast churn                 cppgc_objects=...
fast GC after churn              mode=fast/precise pause=... reclaimed=...
slow churn allocation            elapsed=... auto_gc_count=... auto_gc_time=...
after slow churn                 cppgc_objects=...
slow GC after churn              mode=slow/conservative pause=... reclaimed=...
retained allocation              elapsed=... auto_gc_count=... auto_gc_time=...
after retained batch             cppgc_objects=...
fast GC with retained live       mode=fast/precise pause=... reclaimed=...
after final GC                   cppgc_objects=0 B cppgc_space=0 B rss=...
validation fast_short_lived_allocated=ok ... final_cleanup=ok
```

The sample can be adjusted without recompiling:

```sh
OILPAN_SHORT_LIVED_COUNT=10000000 \
OILPAN_QUICK_GC_ROUNDS=10 \
OILPAN_RETAINED_COUNT=100000 \
OILPAN_INITIAL_HEAP_MB=1024 \
./build/oilpan_hello
```

In this benchmark, `fast/precise` uses `StackState::kNoHeapPointers`: the
embedder states that there are no relevant pointers on the stack, so cppgc can
avoid conservative stack scanning. `slow/conservative` uses
`StackState::kMayContainHeapPointers`, forcing the conservative path.

`OILPAN_INITIAL_HEAP_MB` adjusts `HeapOptions::ResourceConstraints::
initial_heap_size_bytes`. Oilpan does not treat it as a maximum, but as the base
for the moving growth limit. With this sample's atomic heap, the first automatic
GC starts at roughly `initial_heap * 1.5` bytes of live plus new cppgc objects.
If allocation crosses that threshold, the benchmark prints `auto_gc_count` and
`auto_gc_time` during the allocation phase.

## Build GC Only

The `gc/` directory can also be built on its own:

```sh
make -C gc
```

This creates the static library at:

```text
gc/build/liboilpan_gc.a
```

## Structure

- `gc/include/cppgc`: public cppgc headers used by the sample.
- `gc/src/heap/cppgc`: Oilpan/cppgc implementation.
- `gc/src/heap/base` and `gc/src/base`: minimal heap, platform, logging, memory,
  and synchronization support.
- `gc/CMakeLists.txt` and `gc/Makefile`: standalone build for `liboilpan_gc.a`.
- `src/main.cpp`: example using `GarbageCollected`, `Member`, `Persistent`, a
  long-lived object, batches of short-lived objects, a batch retained by roots,
  memory snapshots, forced GC, and benchmark timings.

The sample uses its own minimal platform (`OilpanPlatform`) instead of
`cppgc::DefaultPlatform`, because that class pulls in V8's `libplatform`. To keep
the example small, the heap is created with atomic marking and sweeping.

## Licenses

The vendored Oilpan/cppgc code keeps the V8 project's BSD notices in
`gc/LICENSE.v8`. `gc/third_party/rapidhash-v8` keeps its BSD-2-Clause license in
`gc/third_party/rapidhash-v8/LICENSE`.

## Cleaning

```sh
make clean
```

To clean only the library build:

```sh
make -C gc clean
```

If `third_party/` still exists from an older V8-based build, it is no longer
used. To remove it along with `build/`:

```sh
make distclean
```
