#include <array>
#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <ostream>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <cppgc/allocation.h>
#include <cppgc/garbage-collected.h>
#include <cppgc/heap.h>
#include <cppgc/member.h>
#include <cppgc/persistent.h>
#include <cppgc/process-heap-statistics.h>
#include <cppgc/visitor.h>
#include <src/base/page-allocator.h>
#include <src/base/platform/time.h>
#include <src/heap/cppgc/heap.h>
#include <src/heap/cppgc/metric-recorder.h>

#if defined(__APPLE__)
#include <mach/mach.h>
#elif defined(__linux__)
#include <unistd.h>
#endif

namespace {

constexpr size_t kDefaultShortLivedCount = 1'000'000;
constexpr size_t kDefaultQuickGcRounds = 5;
constexpr size_t kDefaultRetainedCount = 50'000;
constexpr size_t kMiB = 1024 * 1024;
constexpr size_t kDefaultInitialHeapSizeBytes = 512 * kMiB;
constexpr double kOilpanGrowingFactor = 1.5;

using Clock = std::chrono::steady_clock;

struct BenchmarkConfig {
  size_t short_lived_count;
  size_t quick_gc_rounds;
  size_t retained_count;
  size_t initial_heap_size_bytes;
};

class OilpanPlatform final : public cppgc::Platform {
 public:
  cppgc::PageAllocator* GetPageAllocator() override { return &allocator_; }

  double MonotonicallyIncreasingTime() override {
    return v8::base::TimeTicks::Now().ToInternalValue() /
           static_cast<double>(v8::base::Time::kMicrosecondsPerSecond);
  }

 private:
  v8::base::PageAllocator allocator_;
};

size_t CurrentResidentSetBytes() {
#if defined(__APPLE__)
  task_vm_info_data_t info;
  mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
  if (task_info(mach_task_self(), TASK_VM_INFO,
                reinterpret_cast<task_info_t>(&info), &count) == KERN_SUCCESS) {
    return static_cast<size_t>(info.resident_size);
  }
  return 0;
#elif defined(__linux__)
  std::ifstream statm("/proc/self/statm");
  size_t total_pages = 0;
  size_t resident_pages = 0;
  statm >> total_pages >> resident_pages;
  const long page_size = sysconf(_SC_PAGESIZE);
  if (!statm || page_size <= 0) return 0;
  return resident_pages * static_cast<size_t>(page_size);
#else
  return 0;
#endif
}

std::string FormatBytes(size_t bytes) {
  std::ostringstream output;
  output << bytes << " B";
  if (bytes > 0) {
    output << " (" << std::fixed << std::setprecision(2)
           << static_cast<double>(bytes) / (1024.0 * 1024.0) << " MiB)";
  }
  return output.str();
}

std::string FormatMillis(double milliseconds) {
  std::ostringstream output;
  output << std::fixed << std::setprecision(3) << milliseconds << " ms";
  return output.str();
}

size_t ReadPositiveSizeEnv(const char* name, size_t fallback) {
  const char* raw = std::getenv(name);
  if (!raw || !*raw) return fallback;

  errno = 0;
  char* end = nullptr;
  const unsigned long long value = std::strtoull(raw, &end, 10);
  if (errno != 0 || end == raw || *end != '\0' || value == 0 ||
      value > std::numeric_limits<size_t>::max()) {
    std::cerr << "Ignoring invalid " << name << "=" << raw
              << ", using " << fallback << '\n';
    return fallback;
  }

  return static_cast<size_t>(value);
}

size_t ReadPositiveMiBEnv(const char* name, size_t fallback_bytes) {
  const char* raw = std::getenv(name);
  if (!raw || !*raw) return fallback_bytes;

  errno = 0;
  char* end = nullptr;
  const unsigned long long value = std::strtoull(raw, &end, 10);
  if (errno != 0 || end == raw || *end != '\0' || value == 0 ||
      value > std::numeric_limits<size_t>::max() / kMiB) {
    std::cerr << "Ignoring invalid " << name << "=" << raw
              << ", using " << FormatBytes(fallback_bytes) << '\n';
    return fallback_bytes;
  }

  return static_cast<size_t>(value) * kMiB;
}

BenchmarkConfig LoadBenchmarkConfig() {
  return {
      ReadPositiveSizeEnv("OILPAN_SHORT_LIVED_COUNT",
                          kDefaultShortLivedCount),
      ReadPositiveSizeEnv("OILPAN_QUICK_GC_ROUNDS", kDefaultQuickGcRounds),
      ReadPositiveSizeEnv("OILPAN_RETAINED_COUNT", kDefaultRetainedCount),
      ReadPositiveMiBEnv("OILPAN_INITIAL_HEAP_MB",
                         kDefaultInitialHeapSizeBytes),
  };
}

struct MemorySnapshot {
  size_t cppgc_object_bytes;
  size_t cppgc_space_bytes;
  size_t rss_bytes;
};

MemorySnapshot ReadSnapshot() {
  return {
      cppgc::ProcessHeapStatistics::TotalAllocatedObjectSize(),
      cppgc::ProcessHeapStatistics::TotalAllocatedSpace(),
      CurrentResidentSetBytes(),
  };
}

void PrintSnapshot(std::string_view label, const MemorySnapshot& snapshot) {
  std::cout << std::left << std::setw(32) << label
            << " cppgc_objects=" << FormatBytes(snapshot.cppgc_object_bytes)
            << " cppgc_space=" << FormatBytes(snapshot.cppgc_space_bytes)
            << " rss=" << FormatBytes(snapshot.rss_bytes) << '\n';
}

MemorySnapshot TakeSnapshot(std::string_view label) {
  const MemorySnapshot snapshot = ReadSnapshot();
  PrintSnapshot(label, snapshot);
  return snapshot;
}

class LongLivedRecord final : public cppgc::GarbageCollected<LongLivedRecord> {
 public:
  explicit LongLivedRecord(std::string text) : text_(std::move(text)) {
    for (size_t i = 0; i < payload_.size(); ++i) {
      payload_[i] = static_cast<uint64_t>(text_.size() + i);
    }
  }

  void Trace(cppgc::Visitor*) const {}

  const std::string& text() const { return text_; }

  uint64_t Checksum() const {
    uint64_t value = 0;
    for (uint64_t item : payload_) {
      value ^= item;
    }
    return value;
  }

 private:
  const std::string text_;
  std::array<uint64_t, 512> payload_;
};

class ShortLivedRecord final
    : public cppgc::GarbageCollected<ShortLivedRecord> {
 public:
  ShortLivedRecord(size_t index, LongLivedRecord* anchor) : anchor_(anchor) {
    for (size_t i = 0; i < payload_.size(); ++i) {
      payload_[i] = static_cast<uint64_t>((index + 1) * (i + 17));
    }
  }

  void Trace(cppgc::Visitor* visitor) const { visitor->Trace(anchor_); }

  uint64_t Checksum() const {
    uint64_t value = 0;
    for (uint64_t item : payload_) {
      value ^= item;
    }
    return value;
  }

 private:
  cppgc::Member<LongLivedRecord> anchor_;
  std::array<uint64_t, 16> payload_;
};

class RetainedRecord final : public cppgc::GarbageCollected<RetainedRecord> {
 public:
  RetainedRecord(size_t index, LongLivedRecord* anchor) : anchor_(anchor) {
    for (size_t i = 0; i < payload_.size(); ++i) {
      payload_[i] = static_cast<uint64_t>((index + 3) * (i + 101));
    }
  }

  void Trace(cppgc::Visitor* visitor) const { visitor->Trace(anchor_); }

  uint64_t Checksum() const {
    uint64_t value = 0;
    for (uint64_t item : payload_) {
      value ^= item;
    }
    return value;
  }

 private:
  cppgc::Member<LongLivedRecord> anchor_;
  std::array<uint64_t, 32> payload_;
};

struct RetainedBatch {
  std::vector<cppgc::Persistent<RetainedRecord>> roots;
  uint64_t checksum = 0;
};

uint64_t AllocateShortLivedObjects(cppgc::Heap& heap,
                                   LongLivedRecord* anchor, size_t count) {
  cppgc::AllocationHandle& allocation = heap.GetAllocationHandle();
  uint64_t checksum = 0;

  for (size_t i = 0; i < count; ++i) {
    auto* record =
        cppgc::MakeGarbageCollected<ShortLivedRecord>(allocation, i, anchor);
    checksum ^= record->Checksum();
  }

  return checksum;
}

RetainedBatch AllocateRetainedObjects(cppgc::Heap& heap,
                                      LongLivedRecord* anchor, size_t count) {
  cppgc::AllocationHandle& allocation = heap.GetAllocationHandle();
  RetainedBatch batch;
  batch.roots.reserve(count);

  for (size_t i = 0; i < count; ++i) {
    auto* record =
        cppgc::MakeGarbageCollected<RetainedRecord>(allocation, i, anchor);
    batch.checksum ^= record->Checksum();
    batch.roots.emplace_back(record);
  }

  return batch;
}

const char* StackModeName(cppgc::Heap::StackState stack_state) {
  return stack_state == cppgc::Heap::StackState::kNoHeapPointers
             ? "fast/precise"
             : "slow/conservative";
}

struct GcRun {
  std::string label;
  cppgc::Heap::StackState stack_state;
  double milliseconds;
  MemorySnapshot before;
  MemorySnapshot after;
};

struct MetricSummary {
  size_t cycle_count = 0;
  double total_ms = 0.0;
  size_t object_bytes_before = 0;
  size_t object_bytes_after = 0;
  size_t object_bytes_freed = 0;
  size_t memory_bytes_before = 0;
  size_t memory_bytes_after = 0;
  size_t memory_bytes_freed = 0;
};

size_t PositiveBytes(int64_t value) {
  return value > 0 ? static_cast<size_t>(value) : 0;
}

int64_t PositiveMicros(int64_t value) { return value > 0 ? value : 0; }

class BenchmarkMetricRecorder final
    : public cppgc::internal::MetricRecorder {
 public:
  void AddMainThreadEvent(const GCCycle& event) override {
    MetricSummary cycle;
    cycle.cycle_count = 1;
    cycle.total_ms =
        static_cast<double>(PositiveMicros(event.total.mark_duration_us) +
                            PositiveMicros(event.total.weak_duration_us) +
                            PositiveMicros(event.total.compact_duration_us) +
                            PositiveMicros(event.total.sweep_duration_us)) /
        1000.0;
    cycle.object_bytes_before = PositiveBytes(event.objects.before_bytes);
    cycle.object_bytes_after = PositiveBytes(event.objects.after_bytes);
    cycle.object_bytes_freed = PositiveBytes(event.objects.freed_bytes);
    cycle.memory_bytes_before = PositiveBytes(event.memory.before_bytes);
    cycle.memory_bytes_after = PositiveBytes(event.memory.after_bytes);
    cycle.memory_bytes_freed = PositiveBytes(event.memory.freed_bytes);
    cycles_.push_back(cycle);
  }

  size_t cycle_count() const { return cycles_.size(); }

  MetricSummary SummarySince(size_t start_index) const {
    MetricSummary summary;
    if (start_index >= cycles_.size()) return summary;

    summary.object_bytes_before = cycles_[start_index].object_bytes_before;
    summary.memory_bytes_before = cycles_[start_index].memory_bytes_before;
    for (size_t i = start_index; i < cycles_.size(); ++i) {
      const MetricSummary& cycle = cycles_[i];
      summary.cycle_count += cycle.cycle_count;
      summary.total_ms += cycle.total_ms;
      summary.object_bytes_after = cycle.object_bytes_after;
      summary.object_bytes_freed += cycle.object_bytes_freed;
      summary.memory_bytes_after = cycle.memory_bytes_after;
      summary.memory_bytes_freed += cycle.memory_bytes_freed;
    }
    return summary;
  }

 private:
  std::vector<MetricSummary> cycles_;
};

size_t ReclaimedObjectBytes(const GcRun& run) {
  if (run.before.cppgc_object_bytes <= run.after.cppgc_object_bytes) return 0;
  return run.before.cppgc_object_bytes - run.after.cppgc_object_bytes;
}

void PrintGcRun(const GcRun& run) {
  std::cout << std::left << std::setw(34) << run.label
            << " mode=" << std::setw(18) << StackModeName(run.stack_state)
            << " pause=" << std::setw(12) << FormatMillis(run.milliseconds)
            << " reclaimed=" << FormatBytes(ReclaimedObjectBytes(run))
            << '\n';
}

GcRun RunTimedGarbageCollection(cppgc::Heap& heap, std::string label,
                                cppgc::Heap::StackState stack_state) {
  const MemorySnapshot before = ReadSnapshot();
  const auto start = Clock::now();
  heap.ForceGarbageCollectionSlow("oilpan-benchmark", label.c_str(),
                                  stack_state);
  const auto end = Clock::now();
  const MemorySnapshot after = ReadSnapshot();

  GcRun run{std::move(label),
            stack_state,
            std::chrono::duration<double, std::milli>(end - start).count(),
            before,
            after};
  PrintGcRun(run);
  return run;
}

struct TimingSummary {
  double min_ms = 0.0;
  double avg_ms = 0.0;
  double max_ms = 0.0;
  double total_ms = 0.0;
};

TimingSummary SummarizeTimings(const std::vector<GcRun>& runs) {
  if (runs.empty()) return {};

  TimingSummary summary;
  summary.min_ms = runs.front().milliseconds;
  summary.max_ms = runs.front().milliseconds;

  for (const GcRun& run : runs) {
    summary.min_ms = std::min(summary.min_ms, run.milliseconds);
    summary.max_ms = std::max(summary.max_ms, run.milliseconds);
    summary.total_ms += run.milliseconds;
  }

  summary.avg_ms = summary.total_ms / runs.size();
  return summary;
}

void PrintTimingSummary(std::string_view label,
                        const std::vector<GcRun>& runs) {
  if (runs.empty()) return;
  const TimingSummary summary = SummarizeTimings(runs);
  std::cout << std::left << std::setw(34) << label
            << " count=" << std::setw(4) << runs.size()
            << " min=" << std::setw(12) << FormatMillis(summary.min_ms)
            << " avg=" << std::setw(12) << FormatMillis(summary.avg_ms)
            << " max=" << FormatMillis(summary.max_ms) << '\n';
}

void PrintAllocationMetrics(std::string_view label, double elapsed_ms,
                            const MetricSummary& automatic_gc) {
  std::cout << std::left << std::setw(34) << label
            << " elapsed=" << std::setw(12) << FormatMillis(elapsed_ms)
            << " auto_gc_count=" << std::setw(4)
            << automatic_gc.cycle_count
            << " auto_gc_time=" << std::setw(12)
            << FormatMillis(automatic_gc.total_ms)
            << " auto_gc_freed="
            << FormatBytes(automatic_gc.object_bytes_freed) << '\n';
}

}  // namespace

int main() {
  const BenchmarkConfig config = LoadBenchmarkConfig();
  auto platform = std::make_shared<OilpanPlatform>();

  cppgc::InitializeProcess(platform->GetPageAllocator());

  {
    cppgc::Heap::HeapOptions options;
    options.marking_support = cppgc::Heap::MarkingType::kAtomic;
    options.sweeping_support = cppgc::Heap::SweepingType::kAtomic;
    options.resource_constraints.initial_heap_size_bytes =
        config.initial_heap_size_bytes;
    options.stack_start_marker.emplace();
    std::unique_ptr<cppgc::Heap> heap =
        cppgc::Heap::Create(platform, std::move(options));
    auto metric_recorder = std::make_unique<BenchmarkMetricRecorder>();
    BenchmarkMetricRecorder* metrics = metric_recorder.get();
    cppgc::internal::Heap::From(heap.get())
        ->SetMetricRecorder(std::move(metric_recorder));

    cppgc::AllocationHandle& allocation = heap->GetAllocationHandle();
    std::cout << "benchmark config short_lived_count="
              << config.short_lived_count
              << " quick_gc_rounds=" << config.quick_gc_rounds
              << " retained_count=" << config.retained_count
              << " initial_heap=" << FormatBytes(config.initial_heap_size_bytes)
              << '\n'
              << "automatic atomic GC starts around "
              << FormatBytes(static_cast<size_t>(
                     config.initial_heap_size_bytes * kOilpanGrowingFactor))
              << " of live+new cppgc object bytes in this sample"
              << '\n'
              << "GC modes: fast/precise=kNoHeapPointers, "
                 "slow/conservative=kMayContainHeapPointers"
              << '\n';
    TakeSnapshot("start");

    cppgc::Persistent<LongLivedRecord> long_lived =
        cppgc::MakeGarbageCollected<LongLivedRecord>(
            allocation, "Hello, Oilpan long-lived root");
    std::cout << long_lived->text() << " checksum="
              << long_lived->Checksum() << '\n';
    const MemorySnapshot after_long_lived = TakeSnapshot("after long-lived");

    std::cout << "\nRepeated quick GCs on a mostly stable heap\n";
    std::vector<GcRun> quick_fast_runs;
    std::vector<GcRun> quick_slow_runs;
    quick_fast_runs.reserve(config.quick_gc_rounds);
    quick_slow_runs.reserve(config.quick_gc_rounds);
    for (size_t i = 0; i < config.quick_gc_rounds; ++i) {
      quick_fast_runs.push_back(RunTimedGarbageCollection(
          *heap, "quick fast GC #" + std::to_string(i + 1),
          cppgc::Heap::StackState::kNoHeapPointers));
    }
    for (size_t i = 0; i < config.quick_gc_rounds; ++i) {
      quick_slow_runs.push_back(RunTimedGarbageCollection(
          *heap, "quick slow GC #" + std::to_string(i + 1),
          cppgc::Heap::StackState::kMayContainHeapPointers));
    }
    PrintTimingSummary("quick fast summary", quick_fast_runs);
    PrintTimingSummary("quick slow summary", quick_slow_runs);

    std::cout << "\nShort-lived churn + fast precise GC\n";
    size_t metric_start = metrics->cycle_count();
    auto allocation_start = Clock::now();
    const uint64_t fast_short_lived_checksum = AllocateShortLivedObjects(
        *heap, long_lived.Get(), config.short_lived_count);
    double allocation_ms =
        std::chrono::duration<double, std::milli>(Clock::now() -
                                                  allocation_start)
            .count();
    PrintAllocationMetrics("fast churn allocation", allocation_ms,
                           metrics->SummarySince(metric_start));
    std::cout << "Allocated " << config.short_lived_count
              << " short-lived objects, checksum="
              << fast_short_lived_checksum << '\n';
    const MemorySnapshot after_fast_churn =
        TakeSnapshot("after fast churn");
    const GcRun fast_churn_gc = RunTimedGarbageCollection(
        *heap, "fast GC after churn",
        cppgc::Heap::StackState::kNoHeapPointers);
    PrintSnapshot("after fast churn GC", fast_churn_gc.after);

    std::cout << "\nShort-lived churn + slow conservative GC\n";
    metric_start = metrics->cycle_count();
    allocation_start = Clock::now();
    const uint64_t slow_short_lived_checksum = AllocateShortLivedObjects(
        *heap, long_lived.Get(), config.short_lived_count);
    allocation_ms =
        std::chrono::duration<double, std::milli>(Clock::now() -
                                                  allocation_start)
            .count();
    PrintAllocationMetrics("slow churn allocation", allocation_ms,
                           metrics->SummarySince(metric_start));
    std::cout << "Allocated " << config.short_lived_count
              << " short-lived objects, checksum="
              << slow_short_lived_checksum << '\n';
    const MemorySnapshot after_slow_churn =
        TakeSnapshot("after slow churn");
    const GcRun slow_churn_gc = RunTimedGarbageCollection(
        *heap, "slow GC after churn",
        cppgc::Heap::StackState::kMayContainHeapPointers);
    PrintSnapshot("after slow churn GC", slow_churn_gc.after);
    const GcRun slow_cleanup_gc = RunTimedGarbageCollection(
        *heap, "fast cleanup after slow GC",
        cppgc::Heap::StackState::kNoHeapPointers);
    PrintSnapshot("after slow cleanup", slow_cleanup_gc.after);

    std::cout << "\nRetained live batch\n";
    metric_start = metrics->cycle_count();
    allocation_start = Clock::now();
    RetainedBatch retained =
        AllocateRetainedObjects(*heap, long_lived.Get(), config.retained_count);
    allocation_ms =
        std::chrono::duration<double, std::milli>(Clock::now() -
                                                  allocation_start)
            .count();
    PrintAllocationMetrics("retained allocation", allocation_ms,
                           metrics->SummarySince(metric_start));
    std::cout << "Allocated " << retained.roots.size()
              << " retained objects, checksum=" << retained.checksum << '\n';
    const MemorySnapshot after_retained =
        TakeSnapshot("after retained batch");
    const GcRun live_heap_gc = RunTimedGarbageCollection(
        *heap, "fast GC with retained live",
        cppgc::Heap::StackState::kNoHeapPointers);
    PrintSnapshot("after retained live GC", live_heap_gc.after);
    retained.roots.clear();
    const GcRun retained_cleanup_gc = RunTimedGarbageCollection(
        *heap, "fast GC after retained clear",
        cppgc::Heap::StackState::kNoHeapPointers);
    PrintSnapshot("after retained cleanup", retained_cleanup_gc.after);

    long_lived.Clear();
    const GcRun final_gc = RunTimedGarbageCollection(
        *heap, "fast final GC",
        cppgc::Heap::StackState::kNoHeapPointers);
    PrintSnapshot("after final GC", final_gc.after);

    const bool fast_short_lived_allocated =
        after_fast_churn.cppgc_object_bytes >
        after_long_lived.cppgc_object_bytes;
    const bool fast_short_lived_reclaimed =
        fast_churn_gc.after.cppgc_object_bytes <
        fast_churn_gc.before.cppgc_object_bytes;
    const bool slow_batch_cleanup =
        slow_cleanup_gc.after.cppgc_object_bytes <
        after_slow_churn.cppgc_object_bytes;
    const bool retained_allocated =
        after_retained.cppgc_object_bytes >
        slow_cleanup_gc.after.cppgc_object_bytes;
    const bool retained_reclaimed =
        retained_cleanup_gc.after.cppgc_object_bytes <
        live_heap_gc.after.cppgc_object_bytes;
    const bool final_cleanup =
        final_gc.after.cppgc_object_bytes <=
        retained_cleanup_gc.after.cppgc_object_bytes;

    std::cout << "\nvalidation fast_short_lived_allocated="
              << (fast_short_lived_allocated ? "ok" : "failed")
              << " fast_short_lived_reclaimed="
              << (fast_short_lived_reclaimed ? "ok" : "failed")
              << " slow_batch_cleanup="
              << (slow_batch_cleanup ? "ok" : "failed")
              << " retained_allocated="
              << (retained_allocated ? "ok" : "failed")
              << " retained_reclaimed="
              << (retained_reclaimed ? "ok" : "failed")
              << " final_cleanup=" << (final_cleanup ? "ok" : "failed")
              << '\n';

    if (!fast_short_lived_allocated || !fast_short_lived_reclaimed ||
        !slow_batch_cleanup || !retained_allocated || !retained_reclaimed ||
        !final_cleanup) {
      return 1;
    }
  }

  cppgc::ShutdownProcess();
  return 0;
}
