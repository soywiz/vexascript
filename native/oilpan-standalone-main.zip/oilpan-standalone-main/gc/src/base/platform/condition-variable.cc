// Copyright 2013 the V8 project authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "src/base/platform/condition-variable.h"

#include <chrono>
#include <errno.h>
#include <time.h>

#include "src/base/platform/time.h"

#if V8_OS_WIN
#include <windows.h>
#endif

namespace v8 {
namespace base {

ConditionVariable::ConditionVariable() = default;
ConditionVariable::~ConditionVariable() = default;

void ConditionVariable::NotifyOne() { native_handle_.notify_one(); }

void ConditionVariable::NotifyAll() { native_handle_.notify_all(); }

void ConditionVariable::Wait(Mutex* mutex) {
  mutex->AssertHeldAndUnmark();
  std::unique_lock<std::mutex> lock(mutex->native_handle_, std::adopt_lock);
  native_handle_.wait(lock);
  lock.release();
  mutex->AssertUnheldAndMark();
}

bool ConditionVariable::WaitFor(Mutex* mutex, const TimeDelta& rel_time) {
  mutex->AssertHeldAndUnmark();
  std::unique_lock<std::mutex> lock(mutex->native_handle_, std::adopt_lock);
  const auto status = native_handle_.wait_for(
      lock, std::chrono::nanoseconds(rel_time.InNanoseconds()));
  lock.release();
  mutex->AssertUnheldAndMark();

  return status != std::cv_status::timeout;
}

}  // namespace base
}  // namespace v8
