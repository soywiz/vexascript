// Copyright 2022 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Originally in Chromium as "base/functional/function_ref.h"
// Slightly adapted for inclusion in V8.
// Copyright 2025 the V8 project authors. All rights reserved.

#ifndef V8_BASE_FUNCTIONAL_FUNCTION_REF_H_
#define V8_BASE_FUNCTIONAL_FUNCTION_REF_H_

#include <concepts>
#include <functional>
#include <type_traits>
#include <utility>

#include "src/base/compiler-specific.h"
#include "src/base/functional/bind-internal.h"
#include "src/base/types/is-instantiation.h"

namespace v8::base {

template <typename Signature>
class FunctionRef;

// Minimal non-owning callable reference used by standalone Oilpan.
template <typename R, typename... Args>
class FunctionRef<R(Args...)> {
  template <typename Functor,
            typename RunType = internal::FunctorTraits<Functor>::RunType>
  static constexpr bool kCompatibleFunctor =
      std::convertible_to<internal::ExtractReturnType<RunType>, R> &&
      std::same_as<internal::ExtractArgs<RunType>, internal::TypeList<Args...>>;

 public:
  template <typename Functor>
    requires kCompatibleFunctor<Functor> &&
             (!is_instantiation<std::decay_t<Functor>, FunctionRef>)
  // NOLINTNEXTLINE(google-explicit-constructor)
  FunctionRef(const Functor& functor V8_LIFETIME_BOUND)
      : object_(const_cast<void*>(static_cast<const void*>(&functor))),
        callback_([](void* object, Args... args) -> R {
          return std::invoke(*static_cast<const Functor*>(object),
                             std::forward<Args>(args)...);
        }) {}

  template <typename Func>
    requires kCompatibleFunctor<Func*>
  // NOLINTNEXTLINE(google-explicit-constructor)
  FunctionRef(Func* func)
      : object_(reinterpret_cast<void*>(func)),
        callback_([](void* object, Args... args) -> R {
          return std::invoke(reinterpret_cast<Func*>(object),
                             std::forward<Args>(args)...);
        }) {}

  FunctionRef() = delete;
  FunctionRef(const FunctionRef&) V8_NOEXCEPT = default;
  FunctionRef& operator=(const FunctionRef&) = delete;

  R operator()(Args... args) const {
    return callback_(object_, std::forward<Args>(args)...);
  }

 private:
  void* object_;
  R (*callback_)(void*, Args...);
};

}  // namespace v8::base

#endif  // V8_BASE_FUNCTIONAL_FUNCTION_REF_H_
