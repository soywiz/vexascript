# Repository Instructions

- Keep all repository content in English. This includes documentation, comments,
  user-facing strings, build or test messages, examples, and any new files added
  to the repo.
- Preserve existing API names, command names, paths, and third-party license text
  exactly when they are part of upstream or generated content.
